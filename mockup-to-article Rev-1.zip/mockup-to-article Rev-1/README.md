## Article Mockup ##
========
This project focused on mocking up an a article only by using basic
html elements. This could also be applied to creating a craigslist article.

###Instructions:

1. Download the zip file.
2. Open the html file in a browser
3. Enjoy
